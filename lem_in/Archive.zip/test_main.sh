clang -Wall -Wextra -Werror lem_in.c
