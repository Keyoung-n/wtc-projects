/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_echo.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: smahomed <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/10 12:36:09 by smahomed          #+#    #+#             */
/*   Updated: 2016/07/25 13:16:00 by smahomed         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../ft_21sh.h"

int		ft_echo1(char **av, int x, int b[4])
{
	int		fd;

	fd = open(av[x + 1], O_WRONLY | O_APPEND);
	if (av[x - 1][0] == '\'' || av[x - 1][0] == '\"')
		write(fd, &av[x - 1][1],\
			ft_strlen(&av[x - 1][1]) - 1);
	else
		write(fd, av[x - 1], ft_strlen(av[x - 1]));
	if (b[0] == 0)
		write(fd, "\n", 1);
	close(fd);
	return (1);
}

int		ft_echoflags(int b[4], char **av)
{
	int		y;
	int		x;

	y = 0;
	b[0] = 4;
	while (--b[0])
		b[b[0]] = 0;
	while (av[++y] && av[y][0] == '-' && (x = -1))
		while (av[y][++x])
		{
			if (av[y][x] == 'n')
				b[0] = 1;
			if (av[y][x] == 'e')
				b[1] = 1;
			if (av[y][x] == 'E')
				b[2] = 1;
		}
	return (y - 1);
}

int		ft_echo(char **av, t_minishell_l *e)
{
	char	t[1024];
	int		b[4];
	int		x;
	int		ib;

	ib = 1;
	t[0] = '\0';
	x = ft_echoflags(b, av);
	while (av[++x])
	{
		ft_strcat(ft_strcat(t, av[x]), " ");
		if (ft_strequ(av[x], ">>") && (ib = 0) == 0)
			ft_echo1(av, x, b);
		if (ft_strequ(av[x], ">") && (ib = 0))
			e->h += 0;
	}
	if (ib == 1)
	{
		write(1, t, ft_strlen(t) - 1);
		if (b[0] == 0)
			write(1, "\n", 1);
	}
	return (1 + e->h * 0);
}
