/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cat.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: smahomed <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/10 12:34:44 by smahomed          #+#    #+#             */
/*   Updated: 2016/07/25 13:15:11 by smahomed         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../ft_21sh.h"

int		ft_cat(char **av, t_minishell_l *e)
{
	int		x;
	char	c;
	int		fd;

	x = 0;
	while (av[++x])
		if ((fd = open(av[x], O_RDONLY)) > 0)
		{
			while (read(fd, &c, 1))
				write(1, &c, 1);
			close(fd);
		}
	return (1 + 0 * e->h);
}
