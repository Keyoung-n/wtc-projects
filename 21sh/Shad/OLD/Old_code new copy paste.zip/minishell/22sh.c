#include "ft_21sh.h"


int     ft_cursor(char c)
{
    tputs(tgetstr("so", 0), 1, ft_ft_putchar);
    ft_printf("\033[1;36m%c\033[00m", c);
    tputs(tgetstr("se", 0), 1, ft_ft_putchar);
    return (0);
}

void	select_c(char c)
{
	tputs(tgetstr("so", 0), 1, ft_ft_putchar);
	ft_printf("%c", c);
	tputs(tgetstr("se", 0), 1, ft_ft_putchar);
}
int     ft_printstring(t_env *e)
{
    int     x;
	int		i;

    x = -1;
	i = 0;
    ft_printf("\33[2K\r");//erases the terminal line.
    while (++x <= e->a[e->y].x)
	{
//		printf("%i ! %i\n", e->cursor, e->start);
		if (e->start != -2 && x > e->start && x < e->end)
				select_c(e->a[e->y].line[x]);
		else if (e->start != 2 && x < e->start && x > e->end)
				select_c(e->a[e->y].line[x]);
		else if (x == e->cursor)// && e->cursor != e->a[e->y].x)
            ft_cursor(e->a[e->y].line[x]);
        else
            ft_printf("%c", e->a[e->y].line[x]);
	}
    if (e->cursor == e->a[e->y].x + 1)
        ft_cursor(' ');
    return (1);
}

int     ft_init(t_env *e, char *node)
{
    t_21line_l  *tmp;
    int         x;

    if ((x = -1) && !e->a)
    {
        e->a = (t_21line_l *)malloc(sizeof(t_21line_l) * e->buffsize);
        while (++x < e->buffsize)
            e->a[x].line = 0;
    }
    else
    {
        e->buffsize += 1024;
        tmp = (t_21line_l *)malloc(sizeof(t_21line_l) * e->buffsize);
        if (e->a)
            while (++x < e->buffsize)
                tmp[x] = e->a[x];
        tmp[++e->y].buff = 1024;//increments
        tmp[e->y].x = -1;
        e->cursor = 0;
        tmp[e->y].line = (char *)malloc(sizeof(char) * tmp[e->y].buff);
        if (e->a)
            free(e->a);
        e->a = tmp;
    }
    return (1);
}

int		ft_ft_putchar(int c)
{
    return (write(2, &c, 1));
}

int     ft_selectinit(t_select_l *e)
{
    struct winsize	win;
//    int			i;
    
//    i = 0;
//    while (++i < 32)
//        signal(i, ft_catchsignal);
    e->enter = 0;
    tgetent(0, getenv("TERM"));
    tcgetattr(0, &(e->term));
    e->term.c_lflag &= ~(ICANON | ECHO);
    e->term.c_cc[VMIN] = 1;
    e->term.c_cc[VTIME] = 0;
    ioctl(0, TIOCGWINSZ, &win);
    e->v[2] = win.ws_col;
    e->v[3] = win.ws_row;
    tcsetattr(0, 0, &(e->term));
    tputs(tgetstr("ti", 0), 1, ft_ft_putchar);
    tputs(tgetstr("vi", 0), 1, ft_ft_putchar);
//ft_clear();
//ft_lstinit1(e);
//ft_selectcol(e);
//ft_output(e);
//ft_winsizecheck(e);
//ft_selectglobal(e, 0);
    return (1);
}

int			ft_selectend(t_select_l *e)
{
    e->term.c_lflag |= (ICANON | ECHO);
    tputs(tgetstr("te", 0), 1, ft_ft_putchar);
    tputs(tgetstr("ve", 0), 1, ft_ft_putchar);
    tcsetattr(0, 0, &(e->term));
//    if (e->enter)
//        ft_print_enter(e);
    return (1);
}
