/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_21sh.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: smahomed <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/10 12:16:17 by smahomed          #+#    #+#             */
/*   Updated: 2016/07/31 10:09:31 by knage            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_21SH_H
# define FT_21SH_H
# include "./libft/libft.h"
# include <sys/wait.h>
# include <fcntl.h>
# include <unistd.h>
# include <stdlib.h>
# include <stdio.h>
# include <signal.h>
# include <term.h>
# include <termios.h>
# include <termcap.h>
# include <sys/ioctl.h>

typedef struct      s_select_l
{
    struct termios	term;
    char			**av;
    char			*name_term;
    int				enter;
    int				v[4];
    char			**ret_tab;
    //t_lst			*lst;
}                   t_select_l;

typedef struct      s_minishell_l
{
	int             h;
	char            **av;
	char            f[5][32];
	int             (*t_f[5]) (char **, struct s_minishell_l *);
}                   t_minishell_l;

typedef struct      s_21line_l
{
    char            *line;
    int             buff;//number of chars in string
    int             x;
}                   t_21line_l;

typedef struct      s_env
{
    t_minishell_l   m;
    t_select_l      s;
    t_21line_l      *a;//2d array
    int             buffsize;
    int             cursor;
    int             y_cursor;
    int             y;
	int				start;
	int				end;
	char			*clip;
}                   t_env;

int                 ft_printstring(t_env *e);
int                 ft_ft_putchar(int c);
int                 ft_init(t_env *e, char *node);
int                 ft_selectinit(t_select_l *e);
int                 ft_selectend(t_select_l *e);
int                 ft_cd(char **av, t_minishell_l *e);
int                 ft_echo(char **av, t_minishell_l *e);
int                 ft_exit(char **av, t_minishell_l *e);
int                 ft_help(char **av, t_minishell_l *e);
int                 ft_cat(char **av, t_minishell_l *e);
#endif
