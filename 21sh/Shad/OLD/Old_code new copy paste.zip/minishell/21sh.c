/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_minishell.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: smahomed <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/10 12:09:09 by smahomed          #+#    #+#             */
/*   Updated: 2016/07/31 12:33:00 by knage            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_21sh.h"

/*
   int		ft_system(const char *command)
   {
   pid_t   father;
   int     ib;

   father = fork();
   if (father == 0)//child processes
   exit(execl("/bin/sh", "sh", "-c", command, (char *) 0));
   else
   ib = (father > 0 && (waitpid(father, &ib, 0) != father));
   return (1);
   }

   int		ft_exec(t_minishell_l *e, char *line)
   {
   int		i;

   i = -1;
   while (++i < e->h)
   if (ft_strcmp(e->av[0], e->f[i]) == 0)
   return ((e->t_f[i])(e->av, e));
   return (ft_strcmp(line, "exit") != 0 && ft_system(line));
   }

   int		ft_initminishell(int h, t_minishell_l *e)
   {
   while (--h > -1)
   e->f[h][0] = '\0';
   ft_strcat(e->f[0], "cd");
   ft_strcat(e->f[1], "help");
   ft_strcat(e->f[2], "exit");
   ft_strcat(e->f[3], "echo");
   ft_strcat(e->f[4], "cat");
   e->t_f[0] = &ft_cd;
   e->t_f[1] = &ft_help;
   e->t_f[2] = &ft_exit;
   e->t_f[3] = &ft_echo;
   e->t_f[4] = &ft_cat;
   return (0);
   }
   */

int     ft_select2(t_env *e, char **line, char b[4])
{
	if (b[0] == 27 && b[1] == 91 && b[2] == 65 && !b[3])
		ft_printstring(e + 0 * (e->y -= (e->y > 0)));
	if (b[0] == 27 && b[1] == 91 && b[2] == 66 && !b[3])
		ft_printstring(e + 0 * (e->y += (e->a[e->y].line != 0)));
	//27 91 65 0 up arrow
	return (0);
}

int     ft_select(t_env *e, char **line)
{//should store the specific charecters in memory and point at them
	char        b[4];
	char		*temp1;
	char		*temp2;
	int         tmp;

	ft_bzero(b, 4);
	read(0, b, 4);
	if (((b[0] == 32 && !b[1]) || (ft_isprint(b[0]) && !b[1])) \
			&& (e->a[e->y].line[++e->a[e->y].x] = b[0]))//user inputs
	{
		e->start = -2;
		e->start = -2;
		ft_printstring(e + 0 * ++e->cursor);
	}
	//if (ft_isprint(b[0]))
	//ft_printf("%d %d %d %d\n", (int)b[0], (int)b[1], (int)b[2], (int)b[3]);
	if (b[0] == 127 && e->a[e->y].x > -1\
			&& ((e->a[e->y].line[e->a[e->y].x] = '\0') || 1))//backspace charecter.
		ft_printstring(e + 0 * (--e->cursor + --e->a[e->y].x));
	if (b[0] == 27 && b[1] == 91 && b[2] == 67 && b[3] == 0)//right arrow.
		ft_printstring(e + 0 * (e->cursor += (e->cursor < e->a[e->y].x + 1)));
	if (b[0] == 27 && b[1] == 91 && b[2] == 68 && b[3] == 0)//left arrow.
		ft_printstring(e + 0 * (e->cursor -= (e->cursor > 0)));
	if (b[0] == 27 && !b[1])//esc key
		return (0);//exits loop; thus ends the programme.
	if (b[0] == -30 && b[1] == -119 && b[2] == -92) //left select
	{
		if (e->start == -2)
		{
			e->start = e->cursor;
			e->end = e->cursor - 1;
		}
		e->cursor--;
		e->end--;
		if (e->start == e->end - 1 && (e->end = -2))
			e->start = -2;
		ft_printstring(e);
	}
	if (b[0] == -30 && b[1] == -119 && b[2] == -91) //right select
	{
		if (e->start == -2)
		{
			e->start = e->cursor - 1;
			e->end = e->cursor;
		}	
		e->cursor++;
		e->end++;
		if (e->start == e->end - 1 && (e->end = -2))
			e->start = -2;
		ft_printstring(e);
	}
	if (b[0] == -61 && b[1] == -89) //copy
	{
		if (e->clip != NULL)
			free(e->clip);
		if (e->start > e->end)
		{
			e->clip = (char *)malloc(sizeof(char *) * (e->start - e->end));
			e->clip = ft_strsub(e->a[e->y].line, e->end + 1, e->start);
		}
		if (e->end > e->start)
		{
			e->clip = (char *)malloc(sizeof(char *) * (e->end - e->start));
			e->clip = ft_strsub(e->a[e->y].line, e->start + 1, e->end);
		}
		e->start = -2;
		ft_printstring(e);
	}
	if (b[0] == -30 && b[1] == -120 && b[2] == -102) //paste
	{
		if (e->clip != NULL)
		{
			temp1 =  ft_strjoin(ft_strsub(e->a[e->y].line, 0, e->cursor), e->clip);
			temp2 = ft_strsub(e->a[e->y].line, e->cursor, ft_strlen(e->a[e->y].line));
			e->a->x = ft_strlen(e->a[e->y].line) + ft_strlen(e->clip);
			free(e->a[e->y].line);
			e->a[e->y].line = ft_strmerge(temp1, temp2);
			ft_printstring(e);
		}
	}
	if (b[0] == -30 && b[1] == -119 && b[2] == -120) //cut
	{
		if (e->clip != NULL)
			free(e->clip);
		if (e->start > e->end)
		{
			e->clip = (char *)malloc(sizeof(char *) * (e->start - e->end));
			e->clip = ft_strsub(e->a[e->y].line, e->end + 1, e->start);
			e->a->x = ft_strlen(e->a[e->y].line) - ft_strlen(e->clip);
			temp1 = ft_strsub(e->a[e->y].line, 0, e->end + 1);
			temp2 = ft_strsub(e->a[e->y].line, e->start, ft_strlen(e->a[e->y].line));
			free(e->a[e->y].line);
			e->a[e->y].line = ft_strmerge(temp1, temp2);
		}
		if (e->end > e->start)
		{
			e->clip = (char *)malloc(sizeof(char *) * (e->end - e->start));
			e->clip = ft_strsub(e->a[e->y].line, e->start + 1, e->end);
			e->a->x = ft_strlen(e->a[e->y].line) - ft_strlen(e->clip);
			temp1 = ft_strsub(e->a[e->y].line, 0, e->start + 1);
			temp2 = ft_strsub(e->a[e->y].line, e->end, ft_strlen(e->a[e->y].line));
			free(e->a[e->y].line);
			e->a[e->y].line = ft_strmerge(temp1, temp2);
		}
		e->start = -2;
		ft_printstring(e);	
	}
	if (b[0] == 10 && !b[1])//\n
	{//send the string line to minishell
		tmp = e->cursor;
		e->start = -2;
		ft_printstring(e + 0 * (e->cursor = -2));
		e->cursor = tmp;
		return (++e->y && ft_init(e, 0) + ft_printf("\n") + ft_printstring(e));//enter key; to send string to minishell
	}
	ft_select2(e, line, b);
	return (1);
}

int		main(void)
{
	t_env       e;
	char		*line;
	int			ib;

	e.m.h = 5;
	e.start = -2;
	e.buffsize = 0;
	e.a = 0;
	e.clip = NULL;
	e.y = -1;//init y pos
	ft_init(&e, 0);
	ft_init(&e, 0);
	//ft_initminishell(e.m.h + 1, &e.m);
	ib = 1;
	ft_selectinit(&e.s);
	while (ft_select(&e, &line))
		;
	ft_selectend(&e.s);
	return (0);
}
