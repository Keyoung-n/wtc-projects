#/bin/bash

make re
./21sh
cat testfile | grep LOL | wc
exit
