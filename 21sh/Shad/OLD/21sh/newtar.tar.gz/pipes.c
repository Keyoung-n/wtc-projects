/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipes.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kcowle <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/19 09:46:36 by kcowle            #+#    #+#             */
/*   Updated: 2016/07/21 16:17:53 by kcowle           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"


void	ft_pipes(t_env *env, char **pcoms, int i)
{
	char **coms;
	int fd[2];
	pid_t pid;
	char buf;
	char *str;

	coms = ft_strsplit(pcoms[i], '|');
	coms[0] = ft_strtrim(coms[0]);
	coms[1] = ft_strtrim(coms[0]);
	pipe(fd);
	pid = fork();
//	if (pid != 0);
//		wait(NULL);
//	else
//	{
//		close(fd[0]);
//		dup2(fd[1], 1);
		ft_putstr("Excecuting");
		*env = get_dir(env, ft_strsplit(coms[0], ' '));
		ft_putstr(env->path);
		*env = ft_excecute(ft_strsplit(coms[0], ' '), ft_c2da(coms), env);
//		close(fd[1]);
//		while (read(fd[0], &buf, 1) > 0)
//		{
//			ft_putchar('a');
//			str = ft_strmcat(str, &buf);
//		}
//		ft_putstr(str);
//	}
}
