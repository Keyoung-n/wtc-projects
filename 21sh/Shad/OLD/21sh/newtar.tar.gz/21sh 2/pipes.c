/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipes.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kcowle <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/19 09:46:36 by kcowle            #+#    #+#             */
/*   Updated: 2016/07/19 11:07:14 by kcowle           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	ft_pipes(t_env *env, char **coms, int i)
{
	int fd[2];
	pid_t father;
	pid_t kid;
	char **line;
	char **coms2;

	coms2 = ft_strsplit(coms[i], '|');
	coms2[0] = ft_strtrim(coms2[0]);
	coms2[1] = ft_strtrim(coms2[1]);
	line = ft_strsplit(coms2[0], ' ');
	father = fork();
	if (father != 0)
		wait(NULL);
	else
	{
		pipe(fd);
		kid = fork();
		if (kid > 0)
		{
			close(fd[0]);
			dup2(fd[1], 1);
			close(fd[1]);
			*env = get_dir(env, line);
			*env = ft_excecute(line, ft_c2da(line), env);
			exit(0);
		}
		else
		{
			line = ft_strsplit(coms2[1], ' ');
			close(fd[1]);
			dup2(fd[0], 0);
			close(fd[0]);
			*env = get_dir(env, line);
			*env = ft_excecute(line, ft_c2da(line), env);
			exit(0);
		}
	}
}
