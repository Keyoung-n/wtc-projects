#include "minishell.h"

int main()
{
	char *str = "abcdefghijklmnopqrstuvwxyz";

	printf("%s", ft_strchr(str, 'a'));
	return (0);
}
