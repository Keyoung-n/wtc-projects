#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//0 sa 1 sb 2 ss 3 pa 4 pb 5 ra 6 rb 7 rr 8 rra 9 rrb 10 rrr

void	ft_sa(int *a, int y, int x)//sa sb
{//0 1
	int		t;

	t = a[y];
	if (a[y] < a[x] && (a[y] = a[x]))
		a[x] = t;
}

void	ft_ss(int *b, int *a)//ss
{//0 1
    ft_sa(a, 1, 2);
    ft_sa(b, 1, 2);
}

void	ft_pa(int *b, int *a)//pa pb
{//0 1
    int     t;
    int     x;
    int     y;
    
    t = b[1];
    x = 0;
    y = 1;
    while (++x != a[0])
        a[x + 1] = a[x];
    while (++y != b[0])
        b[y - 1] = b[y];
    a[1] = t;
    b[0] -= 1;
    a[0] += 1;
}

void    ra(int *a, int t)//ra rb
{
    int     x;

    x = 1;
    while (++x != a[0])
        a[x - 1] = a[x];
    a[x] = t;
}

void    rr(int *a, int *b)
{
    ra(a, a[1]);
    ra(b, b[1]);
}

void    rra(int *a, int t)//rra rrb
{
    int     x;
    
    x = 0;
    while (++x != a[0])
        a[x + 1] = a[x];
    a[1] = t;
}

void    rrr(int *a, int *b)//rrr
{
    ra(a, a[a[0] - 1]);
    ra(b, b[b[0] - 1]);
}

void    ft_st(int *b, int *a, int n)
{
    if (n == 0)
        ft_sa(a, 1, 2);
    if (n == 1)
        ft_sa(b, 1, 2);//sb
   if (n == 2)
        ft_ss(a, b);
    if (n == 3)
        ft_pa(b, a);
    if (n == 4)
        ft_pa(b, a);//pb
    if (n == 5)
        ra(a, a[1]);
    if (n == 6)
        ra(b, b[1]);//rb
    if (n == 7)
        rr(a, b);
    if (n == 8)
        rra(a, a[a[0] - 1]);
    if (n == 9)
        rra(b, b[b[0] - 1]);//rrb
    if (n == 10)
        rrr(a, b);
}

void	ft_sort(int c, int *a, int x, int y)
{
    while (++y != c || (++x != c - 1 && (y = x)))
    	ft_sa(a, y, x);
}

void    ft_init(int ac, int *a)
{
    int     x;
    int		n[ac];

    x = -1;
    while (++x * 2 < ac && (n[x * 2] = a[x * 2]))
        if (x * 2 + 1 < ac && (a[x * 2 + 1]))
            n[x * 2] = a[x * 2 + 1];
}

int     ft_comb(int *comb, int l)
{
    int     g;
    int     b;
    
    g = 0;
    while (g == 0)
    {
        b = 0;
        
        g = 1;
    }
    return (0);
    
}

void    ft_reset(int l)
{
    int     comb[l];
    
    ft_comb(comb, l);
}

int		main(int ac, char **av)
{
	int     x;
	int		n[ac];

	x = 0;
    n[0] = ac;
	n[1] = atoi(av[1]);
	while (++x * 2 < ac && (n[x * 2] = atoi(av[x * 2])))
		if (x * 2 + 1 < ac && (av[x * 2 + 1]))
			n[x * 2 + 1] = atoi(av[x * 2 + 1]);
	ft_sort(ac, n, 1, 1);
	x = -1;
    while (++x < ac)
		printf("%d\n", n[x]);
	return (0);
}
